from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, FormView, View,CreateView,UpdateView,DeleteView
from django.contrib.auth import login
from django.contrib.auth.models import Group
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.http import HttpResponse
from .models import Restaurant, MenuItem, Reservation, User,PreOrder,Feedback
from .forms import ReservationForm,PreOrderForm,FeedbackForm,RegistrationForm,MenuItemForm
from django.urls import reverse_lazy
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin

# Login View
class LoginView(FormView):
    template_name = 'login.html'
    form_class = AuthenticationForm
    success_url = '/restaurants/'

    def form_valid(self, form):
        user = form.get_user()
        login(self.request, user)
        return super().form_valid(form)
    
    def dispatch(self, request, *args, **kwargs):
        if request.user.is_authenticated:
            return redirect(self.success_url)
        return super().dispatch(request, *args, **kwargs)

# Registration View
class RegisterView(FormView):
    template_name = 'register.html'
    form_class = RegistrationForm
    success_url = reverse_lazy('login')

    def form_valid(self, form):
        user = form.save()
        role = form.cleaned_data['role']
        if role == 'restaurant_owner':
            group = Group.objects.get(name='Restaurant Owner')
            user.groups.add(group)
        login(self.request, user)
        return super().form_valid(form)


# Restaurant List View
class RestaurantListView(ListView):
    model = Restaurant
    template_name = 'restaurant_list.html'
    context_object_name = 'restaurants'
    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')  # Redirect to login page if user is not authenticated
        return super().dispatch(request, *args, **kwargs)
    def get_queryset(self):
        return Restaurant.objects.all()
    
# Create a custom view for Restaurant Owners
class MenuItemCreateView(LoginRequiredMixin, UserPassesTestMixin, CreateView):
    model = MenuItem
    form_class = MenuItemForm
    template_name = 'menu_item_form.html'
    success_url = reverse_lazy('restaurant_list')  # Redirect to the restaurant list

    def dispatch(self, request, *args, **kwargs):
        if not request.user.is_authenticated:
            return redirect('login')
        print("User is authenticated:", request.user.username)
        return super().dispatch(request, *args, **kwargs)

    def form_valid(self, form):
        form.instance.restaurant = Restaurant.objects.get(owner=self.request.user)  # Automatically set restaurant
        return super().form_valid(form)

    def test_func(self):
        groups = self.request.user.groups.all()  # Get all the groups
        print(f"User groups: {groups}")
        return self.request.user.groups.filter(name='Restaurant Owner').exists()
    

class MenuItemUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    model = MenuItem
    form_class = MenuItemForm
    template_name = 'menu_item_form.html'
    success_url = reverse_lazy('restaurant_list')

    def test_func(self):
        return self.request.user.role == 'restaurant_owner'


class MenuItemDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    model = MenuItem
    template_name = 'menu_item_confirm_delete.html'
    success_url = reverse_lazy('restaurant_list')

    def test_func(self):
        return self.request.user.role == 'restaurant_owner'


# Menu View (With sorting by price or name)
class MenuItemListView(ListView):
    model = MenuItem
    template_name = 'menu_items.html'
    context_object_name = 'menu_items'

    def get_queryset(self):
        sort_by = self.request.GET.get('sort_by', 'name')  # Default sorting by name
        if sort_by not in ['name', 'price']:
            sort_by = 'name'  # Default to name if an invalid sort option is provided
        return MenuItem.objects.filter(restaurant=self.kwargs['restaurant_id']).order_by(sort_by)
    
    def get_context_data(self, **kwargs):
        # Get the context from the parent class
        context = super().get_context_data(**kwargs)     
        # Get the restaurant object based on the restaurant_id from the URL
        restaurant_id = self.kwargs['restaurant_id']
        restaurant = Restaurant.objects.get(id=restaurant_id)
        # Add the restaurant to the context
        context['restaurant'] = restaurant
        return context
    
# Reservation Form View
class ReservationFormView(FormView):
    template_name = 'reservation_form.html'
    form_class = ReservationForm
    success_url = '/reservations/'

    def dispatch(self, request, *args, **kwargs):
        # Retrieve the restaurant object by ID from the URL
        self.restaurant = Restaurant.objects.get(id=kwargs['restaurant_id'])
        return super().dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['restaurant'] = self.restaurant  # Pass the restaurant to the template
        return context

    def form_valid(self, form):
        print('Form is valid, saving reservation...')
        reservation = form.save(commit=False)
        reservation.user = self.request.user
        reservation.restaurant = self.restaurant  # Set the restaurant for the reservation
        reservation.save()
        print('Reservation saved with ID:', reservation.id)
        return super().form_valid(form)
    def form_invalid(self, form):
        print(form.errors)  # This will print the form errors in the server's console
        return super().form_invalid(form)

class ReservationListView(ListView):
    model = Reservation
    template_name = 'reservation_list.html'
    context_object_name = 'reservations'

    def get_queryset(self):
        return Reservation.objects.filter(user=self.request.user)

# User Profile View
class ProfileView(DetailView):
    model = User
    template_name = 'profile.html'
    context_object_name = 'user'
    def get_object(self):
        return self.request.user


class PreOrderView(View):
    def get(self, request):
        form = PreOrderForm()
        return render(request, 'preorder.html', {'form': form})

    def post(self, request):
        form = PreOrderForm(request.POST)
        if form.is_valid():
            pre_order = form.save(user=request.user)  # Save the order for the current user
            return redirect('preorder_summary', pre_order_id=pre_order.id)  # Redirect to order summary page
        return render(request, 'preorder.html', {'form': form})

class PreOrderSummaryView(View):
    def get(self, request, pre_order_id):
        pre_order = PreOrder.objects.get(id=pre_order_id)
        if pre_order.user != request.user:
            return redirect('restaurant_list')  # Redirect to restaurant list if user is not authorized
        return render(request, 'preorder_summary.html', {'pre_order': pre_order})
    
class FeedbackView(FormView):
    template_name = 'feedback.html'
    form_class = FeedbackForm

    def form_valid(self, form):
        form.instance.user = self.request.user  # Assign the logged-in user
        form.save()
        return redirect('restaurant_list')  # Redirect to the restaurant list page after submitting feedback