from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('login/', views.LoginView.as_view(), name='login'),
    path('logout/', LogoutView.as_view(next_page='login'), name='logout'),  # Redirect to login page after logout
    path('register/', views.RegisterView.as_view(), name='register'),
    path('menu-item/create/', views.MenuItemCreateView.as_view(), name='menu_item_create'),
    path('menu-item/edit/<int:pk>/', views.MenuItemUpdateView.as_view(), name='menu_item_edit'),
    path('menu-item/delete/<int:pk>/', views.MenuItemDeleteView.as_view(), name='menu_item_delete'),
    path('restaurants/', views.RestaurantListView.as_view(), name='restaurant_list'),
    path('restaurants/<int:restaurant_id>/menu-item/', views.MenuItemListView.as_view(), name='menu_items'),
    path('reservations/<int:restaurant_id>/resrvation-form', views.ReservationFormView.as_view(), name='new_reservation'),
    path('reservations/', views.ReservationListView.as_view(), name='reservation_list'),
    path('profile/', views.ProfileView.as_view(), name='profile'),
    path('preorder/', views.PreOrderView.as_view(), name='preorder'),
    path('preorder/summary/<int:pre_order_id>/', views.PreOrderSummaryView.as_view(), name='preorder_summary'),
    path('feedback/', views.FeedbackView.as_view(), name='feedback'),

]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
