from django import forms
from .models import Reservation, MenuItem, PreOrder,Feedback,User
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.forms import UserCreationForm
# Reservation form
class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = [ 'time', 'number_of_people']

    def __init__(self, *args, **kwargs):
        # If a restaurant is passed, set it as a hidden field in the form
        self.restaurant = kwargs.pop('restaurant', None)
        super().__init__(*args, **kwargs)
        
        if self.restaurant:
            self.fields['restaurant'].initial = self.restaurant  # Set the restaurant in the form field

# Menu Item selection form

class MenuItemForm(forms.ModelForm):
    class Meta:
        model = MenuItem
        fields = ['name', 'description', 'price', 'image', 'restaurant']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # You can add custom styling here if you want
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})

class PreOrderForm(forms.Form):
    menu_items = forms.ModelMultipleChoiceField(queryset=MenuItem.objects.all(), widget=forms.CheckboxSelectMultiple)

    def save(self, user):
        # Save the pre-order data
        pre_order = PreOrder.objects.create(user=user)
        pre_order.items.set(self.cleaned_data['menu_items'])  # Add selected items
        pre_order.calculate_total_price()  # Calculate total price
        return pre_order
    

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['restaurant', 'rating', 'comments']

# Login form using default Django AuthenticationForm
class LoginForm(AuthenticationForm):
    class Meta:
        fields = ['username', 'password',]

# Custom user registration form
class RegistrationForm(UserCreationForm):

    class Meta:
        model = User
        fields = ['username', 'email', 'phone_number', 'password1', 'password2','role']