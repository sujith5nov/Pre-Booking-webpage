from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse, Http404
from django.contrib.auth.models import User
from django.views import View
from django.urls import reverse_lazy
from django.contrib.auth import logout
from django.views.generic import ListView, DetailView, CreateView, TemplateView, DeleteView
from django.views.generic.edit import UpdateView
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.auth.decorators import login_required
from .models import Restaurant, Reservation, MenuItem, UserProfile, PreOrder, Feedback, BlockedTime
from .forms import ReservationForm, UserProfileForm, PreOrderForm, FeedbackForm, SignupForm
from django.contrib import messages
from datetime import datetime
from django.utils import timezone

class SignupView(CreateView):
    model = User
    form_class = SignupForm
    template_name = 'reservation_system/signup.html'
    success_url = reverse_lazy('login')  # Redirect to login page after successful signup

    def form_valid(self, form):
        messages.success(self.request, "Account created successfully!")
        return super().form_valid(form)

    def form_invalid(self, form):
        messages.error(self.request, "There was an error creating your account.")
        return super().form_invalid(form)

class HomeView(LoginRequiredMixin, TemplateView):
    template_name = 'reservation_system/home.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['restaurants'] = Restaurant.objects.all()
        return context

class RestaurantListView(ListView):
    model = Restaurant
    template_name = 'reservation_system/restaurant_list.html'
    context_object_name = 'restaurants'

class MenuListView(ListView):
    model = MenuItem
    template_name = 'reservation_system/menu_list.html'
    context_object_name = 'menu_items'

import logging

# Set up logging
logger = logging.getLogger(__name__)

class RestaurantDetailView(DetailView):
    model = Restaurant
    template_name = 'reservation_system/restaurant_detail.html'
    context_object_name = 'restaurant'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)  # Get the default context
        show_form = self.request.GET.get('show_form', False)
        show_preorder_form = self.request.GET.get('show_preorder_form', False)

        context['restaurant'] = self.get_object()  # Add restaurant to context
        context['show_form'] = show_form
        context['show_preorder_form'] = show_preorder_form
        context['reservation_form'] = ReservationForm()

        if show_preorder_form:
            context['preorder_form'] = PreOrderForm()

        return context

    def post(self, request, *args, **kwargs):
        restaurant = self.get_object()  # This gets the current restaurant instance
        self.object = restaurant  # Manually set self.object

        reservation_form = ReservationForm(request.POST)
        preorder_form = PreOrderForm(request.POST)

        # Check if 'show_form' parameter is in the request and handle the reservation form submission
        if 'show_form' in request.GET:
            # First check if the reservation time is blocked
            date_time_str = request.POST.get('date_time')  # Get the submitted reservation time (as string)

            # Convert the date_time_str into a naive datetime object first
            try:
                date_time_naive = datetime.strptime(date_time_str, '%Y-%m-%dT%H:%M')  # Assuming the input format is 'YYYY-MM-DDTHH:MM'
            except ValueError:
                return HttpResponse("Invalid date/time format.", status=400)

            # Convert the naive datetime object to a timezone-aware datetime object
            date_time = timezone.make_aware(date_time_naive, timezone.get_current_timezone())

            # Fetch all blocked times for the restaurant
            blocked_times = BlockedTime.objects.filter(restaurant=restaurant)
            for blocked_time in blocked_times:
                # Ensure blocked times are timezone-aware for comparison
                if blocked_time.start_time <= date_time <= blocked_time.end_time:
                    # If a reason is provided, include it; otherwise, fallback to 'No reason specified'
                    reason = blocked_time.reason if blocked_time.reason else "No reason specified"
                    message = f"This time slot is unavailable due to: {reason}"
                    return render(request, 'reservation_system/blocked_time_form.html', { 
    'message': message,
    'blocked_time_end': blocked_time.end_time.strftime('%I:%M %p') if blocked_time.end_time else 'N/A',  # Safely format end_time
    'restaurant': restaurant  # Pass the entire restaurant object to the template
})

            # If no blocked time is found, now validate the reservation form
            if reservation_form.is_valid():
                reservation = reservation_form.save(commit=False)
                reservation.restaurant = restaurant
                reservation.user = request.user
                reservation.save()
                return redirect('reservation_success')  # Redirect to reservation success page
            else:
                # Return form validation errors if the form is not valid
                return HttpResponse(f"Form errors: {reservation_form.errors}", status=400)

        # Check if 'show_preorder_form' parameter is in the request and handle the preorder form submission
        elif 'show_preorder_form' in request.GET:
            reservations = Reservation.objects.filter(user=request.user, restaurant=restaurant)
            if reservations.exists():
                reservation = reservations.latest('date_time')  # Choose the most recent reservation
            else:
                return HttpResponse("You must make a reservation before placing a preorder.", status=400)

            if preorder_form.is_valid():
                preorder = preorder_form.save(commit=False)
                preorder.user = request.user
                preorder.reservation = reservation
                preorder.save()
                return redirect('preorder_success')  # Redirect to preorder success page
            else:
                return HttpResponse(f"Form errors: {preorder_form.errors}", status=400)

        # If form is invalid or another issue occurs, render the page with errors
        return self.render_to_response(self.get_context_data(
            reservation_form=reservation_form,
            preorder_form=preorder_form
        ))
    
class ReservationCreateView(LoginRequiredMixin, CreateView):
    model = Reservation
    form_class = ReservationForm
    template_name = 'reservation_system/reservation_form.html'

    def form_valid(self, form):
        form.instance.user = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse_lazy('reservation_success')

class ReservationCancelView(LoginRequiredMixin, View):
    """
    View to show the cancellation confirmation page and delete the reservation after confirmation.
    """
    
    def get(self, request, *args, **kwargs):
        reservation = get_object_or_404(Reservation, pk=kwargs['pk'])
        if reservation.user != request.user:
            raise Http404("You are not authorized to cancel this reservation.")
        return render(request, 'reservation_system/confirm_cancel.html', {
            'reservation': reservation,
        })
    
    def post(self, request, *args, **kwargs):
        reservation = get_object_or_404(Reservation, pk=kwargs['pk'])

        if reservation.user != request.user:
            raise Http404("You are not authorized to cancel this reservation.")

        reservation.delete()

        return redirect('user_profile')
    
class UserProfileView(LoginRequiredMixin, TemplateView):
    template_name = 'reservation_system/user_profile.html'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Get or create the user profile for the logged-in user
        user_profile, created = UserProfile.objects.get_or_create(user=self.request.user)

        # Add the user profile and favorite restaurants to the context
        context['user_profile'] = user_profile
        context['form'] = UserProfileForm(instance=user_profile)  # Pre-fill form with user profile data

        # Add reservations and favorite restaurants to the context
        context['reservations'] = Reservation.objects.filter(user=self.request.user)
        context['favorite_restaurants'] = user_profile.favorite_restaurants.all()  # Fetch favorite restaurants

        return context
class ReservationUpdateView(UpdateView):
    model = Reservation
    form_class = ReservationForm
    template_name = 'reservation_system/edit_reservation.html'

    def get_success_url(self):
        return reverse_lazy('user_profile')  # Redirect to the profile page after editing

    def get_object(self, queryset=None):
        """
        Ensure that the user can only edit their own reservation.
        """
        obj = super().get_object(queryset)
        if obj.user != self.request.user:
            raise Http404("You are not authorized to edit this reservation.")
        return obj


def reservation_success(request):
    return render(request, 'reservation_system/reservation_success.html')

def preorder_success(request):
    return render(request, 'reservation_system/preorder_success.html')

def custom_logout(request):
    logout(request)
    return redirect('logout') 

@login_required
def user_profile(request):
    user_profile, created = UserProfile.objects.get_or_create(user=request.user)
    return render(request, 'reservation_system/user_profile.html', {
        'user_profile': user_profile
    })
class FeedbackCreateView(CreateView):
    model = Feedback
    template_name = 'reservation_system/feedback_form.html'
    fields = ['comment', 'rating']
    def form_valid(self, form):
        form.instance.user = self.request.user
        response = super().form_valid(form)
        messages.success(self.request, "Thank you for your feedback!")
        return response
    def get_success_url(self):
        return reverse_lazy('home')

class FeedbackListView(ListView):
    model = Feedback
    template_name = 'reservation_system/feedback_list.html'
    context_object_name = 'feedbacks'
    ordering = ['-created_at']  # Show most recent feedback first
    paginate_by = 10  # Optional, to paginate the feedback list

class BlockedTimeCreateView(LoginRequiredMixin, CreateView):
    model = BlockedTime
    template_name = 'reservation_system/blocked_time_form.html'
    fields = ['start_time', 'end_time', 'reason']

    def form_valid(self, form):
        form.instance.user = self.request.user  # Assign the admin user who is blocking the time
        response = super().form_valid(form)
        messages.success(self.request, "Time slot successfully blocked.")
        return response

    def get_success_url(self):
        return reverse_lazy('blocked_time_list') 

class BlockedTimeListView(LoginRequiredMixin, ListView):
    model = BlockedTime
    template_name = 'blocked_time_list.html'
    context_object_name = 'blocked_times'

    def get_queryset(self):
        # Optionally, you can restrict access to admin users or other conditions
        return BlockedTime.objects.all()

class BlockedTimeDeleteView(LoginRequiredMixin, DeleteView):
    model = BlockedTime
    template_name = 'blocked_time_confirm_delete.html'
    context_object_name = 'blocked_time'
    success_url = reverse_lazy('blocked_time_list')

    def delete(self, request, *args, **kwargs):
        messages.success(self.request, "Blocked time slot successfully removed.")
        return super().delete(request, *args, **kwargs)
    
def user_profile(request):
    reservations = Reservation.objects.filter(user=request.user)
    return render(request, 'reservation_system/edit_reservation.html', {
        'reservations': reservations,
    })

def logout_success(request):
    return render(request, 'reservation_system/logout.html')





