# Create your models here.

from django.db import models
from django.contrib.auth.models import User
from phonenumber_field.modelfields import PhoneNumberField

# Restaurant Model
class Restaurant(models.Model): # declaring a model 
    name = models.CharField(max_length=100) # declaring a field called name with max length of 100 and the restraunt name
    location = models.CharField(max_length=255) # declaring a field called location with max length of 255
    description = models.TextField() # declaring a field called description with max length of 1000
    rating= models. DecimalField(max_digits=3, decimal_places=2, default=0.0, blank=True, null=True) # declaring a field called rating with max
    contact_number= PhoneNumberField() # declaring a field called contact_number with max length of 1000
    def __str__(self): # returns a string representation of the object
        return self.name  # returns the name of the restaurant
    
# MenuItem Model
class MenuItem(models.Model): # declaring a model names Menu items 
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name='menu_items') # declaring a field called restaurant with a foreign key to the restaurant model
    name = models.CharField(max_length=100) # declaring a field called name with max length of 100
    description = models.TextField() # declaring a field called description with max length of 1000
    price = models.DecimalField(max_digits=6, decimal_places=2) # declaring a field called price with max digits of 6 and decimal places of 2

    def __str__(self): # returns a string representation of the object
        return self.name # returns the name of the menu item

# Reservation Model
class Reservation(models.Model): # declaring a model named Reservation
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='reservations') # declaring a field called user with a foreign key to the user model
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name='reservations') # declaring a field called restaurant with a foreign key to the restaurant model
    date_time = models.DateTimeField() # declaring a field called date_time with a datetime field
    guests = models.PositiveIntegerField() # declaring a field called guests with a positive integer field
    special_request = models.TextField(blank=True, null=True) # declaring a field called special_request with a text field that can be blank or null

    def __str__(self): # returns a string representation of the object
        return f"Reservation at {self.restaurant.name} for {self.user.username} on {self.date_time}" # returns a string with the restaurant name, user name, and date time

class PreOrder(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="pre_orders")
    reservation = models.ForeignKey(Reservation, on_delete=models.CASCADE, related_name="pre_orders")
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)  # Number of items ordered

    def __str__(self):
        return f"{self.user.username} - {self.menu_item.name} (x{self.quantity})"
    
# User Profile Model (optional)
class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # User association
    favorite_restaurants = models.ManyToManyField('Restaurant', blank=True)  # Optional: Many-to-many relation with Restaurant model
    User_name = models.CharField(max_length=100,default="Default User", blank=True)  # Now allows an empty string for user_name
    Email = models.EmailField(default="user@example.com",blank=True)  # Allows empty string, no need for `null=True`
    Contact_number = PhoneNumberField(default='0000000000',blank=True)  # Allows empty string for contact_number

    def __str__(self):
        return self.user.username  # String representation of the user profile (linked to the username)

class Feedback(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE, related_name='feedbacks', null=True, blank=True)
    comment = models.TextField()
    rating = models.IntegerField(choices=[(1, '1'), (2, '2'), (3, '3'), (4, '4'), (5, '5')], default=5)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback from {self.user.username if self.user else 'Anonymous'}"

    class Meta:
        verbose_name = 'Feedback'
        verbose_name_plural = 'Feedbacks'

class BlockedTime(models.Model):
    restaurant = models.ForeignKey(Restaurant, on_delete=models.CASCADE, related_name='blocked_times', null=True, blank=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Admin user who blocked the time
    start_time = models.DateTimeField()  # Start of the blocked period
    end_time = models.DateTimeField()  # End of the blocked period
    reason = models.TextField(blank=True, null=True)  # Reason for blocking, optional
    created_at = models.DateTimeField(auto_now_add=True)  # When the block was created

    def __str__(self):
        return f"Blocked from {self.start_time} to {self.end_time}"

    class Meta:
        verbose_name = 'Blocked Time'
        verbose_name_plural = 'Blocked Times'


