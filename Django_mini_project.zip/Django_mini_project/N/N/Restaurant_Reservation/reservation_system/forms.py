from django import forms
from .models import Reservation, UserProfile, PreOrder, MenuItem, Feedback, BlockedTime
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['restaurant', 'date_time', 'guests', 'special_request']
        widgets = {
            'date_time': forms.DateTimeInput(attrs={'type': 'datetime-local'}),  # To allow proper datetime input
        }

    def clean_date_time(self):
        date_time = self.cleaned_data['date_time']
        restaurant = self.cleaned_data['restaurant']
    
        # Check if the reservation time falls within any blocked time range
        blocked_times = BlockedTime.objects.filter(restaurant=restaurant)
        for blocked_time in blocked_times:
            # Check if the date_time falls between start_time and end_time
            if blocked_time.start_time <= date_time <= blocked_time.end_time:
                raise forms.ValidationError("This time slot is unavailable due to a blocked time.")

        # You can also check for other existing reservations at the same time
        if Reservation.objects.filter(restaurant=restaurant, date_time=date_time).exists():
            raise forms.ValidationError("The restaurant is fully booked for this time.")
        
        return date_time


class UserProfileForm(forms.ModelForm):
    class Meta:
        model = UserProfile
        fields = ['User_name', 'Email', 'Contact_number', 'favorite_restaurants']  # Exclude the 'user' field
        widgets = {
            'favorite_restaurants': forms.CheckboxSelectMultiple,  # Display favorite restaurants as checkboxes
        }

    def clean_Email(self):
        email = self.cleaned_data.get('Email')
        # Example validation: Ensure email has a valid format
        if email and not '@' in email:
            raise forms.ValidationError("Please enter a valid email address.")
        return email

    def clean_Contact_number(self):
        contact_number = self.cleaned_data.get('Contact_number')
        # Example validation: Ensure contact number is not too short
        if contact_number and len(str(contact_number)) < 10:
            raise forms.ValidationError("Please enter a valid contact number with at least 10 digits.")
        return contact_number

class SignupForm(UserCreationForm):
    email = forms.EmailField(max_length=255, required=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

class PreOrderForm(forms.ModelForm):
    class Meta:
        model = PreOrder
        fields = ['menu_item', 'quantity']  # Fields for preorder (menu item, quantity)

    def __init__(self, *args, **kwargs):
        # Pass reservation explicitly from view to the form
        self.reservation = kwargs.pop('reservation', None)
        super().__init__(*args, **kwargs)

    def save(self, commit=True):
        # Save the PreOrder instance
        instance = super().save(commit=False)
        if self.reservation:
            instance.reservation = self.reservation  # Set reservation explicitly
        if hasattr(self, 'user') and self.user:
            instance.user = self.user  # Set user explicitly if available
        if commit:
            instance.save()  # Save to the database
        return instance

class FeedbackForm(forms.ModelForm):
    class Meta:
        model = Feedback
        fields = ['comment', 'rating']
        widgets = {
            'comment': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Write your feedback here...'}),
            'rating': forms.Select(attrs={'class': 'rating-dropdown'}),
        }
