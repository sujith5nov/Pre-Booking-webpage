from django.urls import path
from django.contrib.auth.views import LoginView, LogoutView
from . import views

urlpatterns = [
    # Login and Logout URLs
    path('login/', LoginView.as_view(template_name='login.html'), name='login'),
    path('logout/', views.custom_logout, name='logout'),  # Custom logout view
    path('signup/', views.SignupView.as_view(), name='signup'),

    # Home page and other views
    path('', views.HomeView.as_view(), name='home'),  # Home page protected by login
    path('restaurants/', views.RestaurantListView.as_view(), name='restaurant_list'),
    path('restaurant/<int:pk>/', views.RestaurantDetailView.as_view(), name='restaurant_detail'),
    path('menu/', views.MenuListView.as_view(), name='menu_list'),
    
    # Reservation views
    path('reserve/', views.ReservationCreateView.as_view(), name='reserve'),
    path('reservation/<int:reservation_id>/preorder/', views.RestaurantDetailView.as_view(), name='preorder_view'),
    path('reservation/success/', views.reservation_success, name='reservation_success'),

    # Preorder success view
    path('preorder/success/', views.preorder_success, name='preorder_success'),

    # Reservation cancellation view
    path('reservation/edit/<int:pk>/', views.ReservationUpdateView.as_view(), name='edit_reservation'),
    path('reservation/<int:pk>/cancel/', views.ReservationCancelView.as_view(), name='reservation_cancel'),
    path('feedback/', views.FeedbackCreateView.as_view(), name='feedback'),
    path('feedbacks/', views.FeedbackListView.as_view(), name='feedback_list'),
    path('blocked-times/', views.BlockedTimeListView.as_view(), name='blocked_time_list'),
    path('blocked-time/create/', views.BlockedTimeCreateView.as_view(), name='blocked_time_create'),
    path('blocked-time/delete/<int:pk>/', views.BlockedTimeDeleteView.as_view(), name='blocked_time_delete'),

    # User Profile URL
    path('profile/', views.UserProfileView.as_view(), name='user_profile'),

    # Custom logout success page
    path('logout/success/', views.logout_success, name='logout_success'),
]







