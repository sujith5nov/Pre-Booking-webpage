# Register your models here.
from django.contrib import admin # admin is being imported using a django model named django.contrib
from .models import Restaurant, MenuItem, Reservation, UserProfile, PreOrder , Feedback , BlockedTime# importing models from the current app- reservation_system

admin.site.register(Restaurant) # registering the Restaurant model in the admin interface
admin.site.register(MenuItem) # registering the MenuItem model in the admin interface
admin.site.register(Reservation) # registering the Reservation model in the admin interface
admin.site.register(UserProfile) # registering the UserProfile model in the admin interface
admin.site.register(PreOrder) # registering the PreOrder model in the admin interface
admin.site.register(Feedback) # registering the Feedback model in the admin interface
admin.site.register(BlockedTime) # registering the BlockedTime model in the admin interface
